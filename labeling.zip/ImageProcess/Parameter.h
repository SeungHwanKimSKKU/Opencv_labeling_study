#define RED				0
#define BLUE			1
#define GREEN			2

#define TH_BALL_H_L		100;
#define TH_BALL_H_H		200;
#define TH_BALL_S_L		100;
#define TH_BALL_S_H		200;

#define TH_RED_H_L		0;
#define TH_RED_H_H		50;
#define TH_RED_S_L		0;
#define TH_RED_S_H		200;

#define TH_BLUE_H_L		250;
#define TH_BLUE_H_H		200;
#define TH_BLUE_S_L		0;
#define TH_BLUE_S_H		200;

#define TH_GREEN_H_L	50;
#define TH_GREEN_H_H	150;
#define TH_GREEN_S_L	0;
#define TH_GREEN_S_H	200;